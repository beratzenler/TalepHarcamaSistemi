﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace TalepVeHarcamaSistemi
{
    public partial class Kullanicilarcs : Form
    {
        public Kullanicilarcs()
        {
            InitializeComponent();
        }

        private void Kullanicilarcs_Load(object sender, EventArgs e)
        {
            // TODO: Bu kod satırı 'sIRKETDataSet.Talep' tablosuna veri yükler. Bunu gerektiği şekilde taşıyabilir, veya kaldırabilirsiniz.
            this.talepTableAdapter.Fill(this.sIRKETDataSet.Talep);

        }
        SqlConnection conn = new SqlConnection("Data Source = LAPTOP - P9GCCN15; Initial Catalog = SIRKET; Integrated Security = True; Encrypt = False; Trust Server Certificate = True");
    }
}
