﻿namespace TalepVeHarcamaSistemi
{
    partial class Yoneticiler
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.taleplerBtn = new System.Windows.Forms.Button();
            this.harcamalarBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // taleplerBtn
            // 
            this.taleplerBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.taleplerBtn.Location = new System.Drawing.Point(393, 151);
            this.taleplerBtn.Name = "taleplerBtn";
            this.taleplerBtn.Size = new System.Drawing.Size(403, 171);
            this.taleplerBtn.TabIndex = 0;
            this.taleplerBtn.Text = "TALEPLER";
            this.taleplerBtn.UseVisualStyleBackColor = true;
            this.taleplerBtn.Click += new System.EventHandler(this.taleplerBtn_Click);
            // 
            // harcamalarBtn
            // 
            this.harcamalarBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.harcamalarBtn.Location = new System.Drawing.Point(393, 367);
            this.harcamalarBtn.Name = "harcamalarBtn";
            this.harcamalarBtn.Size = new System.Drawing.Size(403, 171);
            this.harcamalarBtn.TabIndex = 1;
            this.harcamalarBtn.Text = "HARCAMALAR";
            this.harcamalarBtn.UseVisualStyleBackColor = true;
            // 
            // Yoneticiler
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1257, 688);
            this.Controls.Add(this.harcamalarBtn);
            this.Controls.Add(this.taleplerBtn);
            this.Name = "Yoneticiler";
            this.Text = "Yoneticiler";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Yoneticiler_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button taleplerBtn;
        private System.Windows.Forms.Button harcamalarBtn;
    }
}