﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace TalepVeHarcamaSistemi
{
    public partial class girisPaneli : Form
    {
        public girisPaneli()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        SqlConnection conn;
        SqlCommand cmd;
        SqlDataReader reader;

        /*   private void girisYap_Click(object sender, EventArgs e)
           {

               conn = new SqlConnection("Data Source=LAPTOP-P9GCCN15;Initial Catalog=SIRKET;Integrated Security=True;TrustServerCertificate=True;");
               cmd = new SqlCommand();
               cmd.Connection = conn;
               try
               {
                   conn.Open();

                   cmd.CommandText = "Select * from Kullanici where KullaniciAdi='" + kullaniciAdi.Text + "' and Sifre='" + sifre.Text + "'";
                   reader = cmd.ExecuteReader();

                   if (reader.Read())
                   {
                       if (comboBoxRol.SelectedItem.ToString() == "Kullanici")
                       {
                           new Kullanicilarcs().Show();
                       }
                       else
                       {
                           MessageBox.Show("Hatalı Giriş.");
                       }

                       if (comboBoxRol.SelectedItem.ToString() == "Yönetici")
                       {
                           new Yoneticiler().Show();
                       }
                       else
                       {
                           MessageBox.Show("Hatalı Giriş");
                       }

                   }

               }
               catch (Exception ex)
               {
                   MessageBox.Show(ex.Message);
               }
           }*/
        private void girisYap_Click(object sender, EventArgs e)
        {
            string kullaniciadi = kullaniciAdi.Text.Trim();
            string sifreDegeri = sifre.Text.Trim();
            string secilenRol = comboBoxRol.SelectedItem?.ToString();

            if (string.IsNullOrEmpty(secilenRol))
            {
                MessageBox.Show("Lütfen bir rol seçiniz.");
                return;
            }

            conn = new SqlConnection("Data Source=LAPTOP-P9GCCN15;Initial Catalog=SIRKET;Integrated Security=True;TrustServerCertificate=True;");
            cmd = new SqlCommand("SELECT * FROM Kullanici WHERE KullaniciAdi = @kullaniciAdi AND Sifre = @sifre", conn);
            cmd.Parameters.AddWithValue("@kullaniciAdi", kullaniciadi);
            cmd.Parameters.AddWithValue("@sifre", sifreDegeri);

            try
            {
                conn.Open();
                reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    string veritabaniRolu = reader["Rol"]?.ToString();

                    if (string.Equals(veritabaniRolu, secilenRol, StringComparison.OrdinalIgnoreCase))
                    {
                        if (veritabaniRolu == secilenRol)
                        {
                            if (veritabaniRolu == "kullanici")
                            {
                                new Kullanicilarcs().Show();
                                this.Hide();
                            }
                            else if (veritabaniRolu == "yonetici")
                            {
                                new Yoneticiler().Show();
                                this.Hide();
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Rol uyuşmuyor. Lütfen doğru rolü seçin.");
                    }
                }
                else
                {
                    MessageBox.Show("Kullanıcı adı veya şifre hatalı.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                if (reader != null && !reader.IsClosed)
                    reader.Close();

                if (conn.State == ConnectionState.Open)
                    conn.Close();
            }
        }

    }
}
