﻿namespace TalepVeHarcamaSistemi
{
    partial class Kullanicilarcs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.talepIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kullaniciIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kategoriIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.talepAciklamaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.talepTarihiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.talepBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sIRKETDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sIRKETDataSet = new TalepVeHarcamaSistemi.SIRKETDataSet();
            this.btn_listele = new System.Windows.Forms.Button();
            this.btn_ekle = new System.Windows.Forms.Button();
            this.btn_guncelle = new System.Windows.Forms.Button();
            this.btn_sil = new System.Windows.Forms.Button();
            this.btn_ara = new System.Windows.Forms.Button();
            this.txtAra = new System.Windows.Forms.TextBox();
            this.kullanici_id = new System.Windows.Forms.TextBox();
            this.kateogori_id = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.talepTableAdapter = new TalepVeHarcamaSistemi.SIRKETDataSetTableAdapters.TalepTableAdapter();
            this.talep_aciklama = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.talep_tarihi = new System.Windows.Forms.MaskedTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.talepBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sIRKETDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sIRKETDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.talepIDDataGridViewTextBoxColumn,
            this.kullaniciIDDataGridViewTextBoxColumn,
            this.kategoriIDDataGridViewTextBoxColumn,
            this.talepAciklamaDataGridViewTextBoxColumn,
            this.talepTarihiDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.talepBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(229, 230);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(664, 405);
            this.dataGridView1.TabIndex = 0;
            // 
            // talepIDDataGridViewTextBoxColumn
            // 
            this.talepIDDataGridViewTextBoxColumn.DataPropertyName = "TalepID";
            this.talepIDDataGridViewTextBoxColumn.HeaderText = "TalepID";
            this.talepIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.talepIDDataGridViewTextBoxColumn.Name = "talepIDDataGridViewTextBoxColumn";
            this.talepIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.talepIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // kullaniciIDDataGridViewTextBoxColumn
            // 
            this.kullaniciIDDataGridViewTextBoxColumn.DataPropertyName = "KullaniciID";
            this.kullaniciIDDataGridViewTextBoxColumn.HeaderText = "KullaniciID";
            this.kullaniciIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.kullaniciIDDataGridViewTextBoxColumn.Name = "kullaniciIDDataGridViewTextBoxColumn";
            this.kullaniciIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // kategoriIDDataGridViewTextBoxColumn
            // 
            this.kategoriIDDataGridViewTextBoxColumn.DataPropertyName = "KategoriID";
            this.kategoriIDDataGridViewTextBoxColumn.HeaderText = "KategoriID";
            this.kategoriIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.kategoriIDDataGridViewTextBoxColumn.Name = "kategoriIDDataGridViewTextBoxColumn";
            this.kategoriIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // talepAciklamaDataGridViewTextBoxColumn
            // 
            this.talepAciklamaDataGridViewTextBoxColumn.DataPropertyName = "TalepAciklama";
            this.talepAciklamaDataGridViewTextBoxColumn.HeaderText = "TalepAciklama";
            this.talepAciklamaDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.talepAciklamaDataGridViewTextBoxColumn.Name = "talepAciklamaDataGridViewTextBoxColumn";
            this.talepAciklamaDataGridViewTextBoxColumn.Width = 125;
            // 
            // talepTarihiDataGridViewTextBoxColumn
            // 
            this.talepTarihiDataGridViewTextBoxColumn.DataPropertyName = "TalepTarihi";
            this.talepTarihiDataGridViewTextBoxColumn.HeaderText = "TalepTarihi";
            this.talepTarihiDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.talepTarihiDataGridViewTextBoxColumn.Name = "talepTarihiDataGridViewTextBoxColumn";
            this.talepTarihiDataGridViewTextBoxColumn.Width = 125;
            // 
            // talepBindingSource
            // 
            this.talepBindingSource.DataMember = "Talep";
            this.talepBindingSource.DataSource = this.sIRKETDataSetBindingSource;
            // 
            // sIRKETDataSetBindingSource
            // 
            this.sIRKETDataSetBindingSource.DataSource = this.sIRKETDataSet;
            this.sIRKETDataSetBindingSource.Position = 0;
            // 
            // sIRKETDataSet
            // 
            this.sIRKETDataSet.DataSetName = "SIRKETDataSet";
            this.sIRKETDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // btn_listele
            // 
            this.btn_listele.BackColor = System.Drawing.Color.Lime;
            this.btn_listele.Location = new System.Drawing.Point(561, 62);
            this.btn_listele.Name = "btn_listele";
            this.btn_listele.Size = new System.Drawing.Size(77, 112);
            this.btn_listele.TabIndex = 1;
            this.btn_listele.Text = "LİSTELE";
            this.btn_listele.UseVisualStyleBackColor = false;
            // 
            // btn_ekle
            // 
            this.btn_ekle.BackColor = System.Drawing.Color.Yellow;
            this.btn_ekle.Location = new System.Drawing.Point(644, 62);
            this.btn_ekle.Name = "btn_ekle";
            this.btn_ekle.Size = new System.Drawing.Size(75, 112);
            this.btn_ekle.TabIndex = 2;
            this.btn_ekle.Text = "EKLE";
            this.btn_ekle.UseVisualStyleBackColor = false;
            // 
            // btn_guncelle
            // 
            this.btn_guncelle.BackColor = System.Drawing.Color.Purple;
            this.btn_guncelle.ForeColor = System.Drawing.SystemColors.Control;
            this.btn_guncelle.Location = new System.Drawing.Point(733, 62);
            this.btn_guncelle.Name = "btn_guncelle";
            this.btn_guncelle.Size = new System.Drawing.Size(89, 112);
            this.btn_guncelle.TabIndex = 3;
            this.btn_guncelle.Text = "GÜNCELLE";
            this.btn_guncelle.UseVisualStyleBackColor = false;
            // 
            // btn_sil
            // 
            this.btn_sil.BackColor = System.Drawing.Color.Red;
            this.btn_sil.Location = new System.Drawing.Point(828, 62);
            this.btn_sil.Name = "btn_sil";
            this.btn_sil.Size = new System.Drawing.Size(81, 112);
            this.btn_sil.TabIndex = 4;
            this.btn_sil.Text = "SİL";
            this.btn_sil.UseVisualStyleBackColor = false;
            // 
            // btn_ara
            // 
            this.btn_ara.Location = new System.Drawing.Point(676, 12);
            this.btn_ara.Name = "btn_ara";
            this.btn_ara.Size = new System.Drawing.Size(118, 44);
            this.btn_ara.TabIndex = 5;
            this.btn_ara.Text = "ARA";
            this.btn_ara.UseVisualStyleBackColor = true;
            // 
            // txtAra
            // 
            this.txtAra.Location = new System.Drawing.Point(455, 23);
            this.txtAra.Name = "txtAra";
            this.txtAra.Size = new System.Drawing.Size(183, 22);
            this.txtAra.TabIndex = 6;
            // 
            // kullanici_id
            // 
            this.kullanici_id.Location = new System.Drawing.Point(326, 62);
            this.kullanici_id.Name = "kullanici_id";
            this.kullanici_id.Size = new System.Drawing.Size(183, 22);
            this.kullanici_id.TabIndex = 7;
            // 
            // kateogori_id
            // 
            this.kateogori_id.Location = new System.Drawing.Point(326, 107);
            this.kateogori_id.Name = "kateogori_id";
            this.kateogori_id.Size = new System.Drawing.Size(183, 22);
            this.kateogori_id.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(171, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 22);
            this.label1.TabIndex = 10;
            this.label1.Text = "Kullanıcı Id:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(171, 105);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(124, 22);
            this.label2.TabIndex = 11;
            this.label2.Text = "Kategori Id:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(171, 153);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(153, 22);
            this.label3.TabIndex = 12;
            this.label3.Text = "Talep Açıklama:";
            // 
            // talepTableAdapter
            // 
            this.talepTableAdapter.ClearBeforeFill = true;
            // 
            // talep_aciklama
            // 
            this.talep_aciklama.Location = new System.Drawing.Point(326, 153);
            this.talep_aciklama.Name = "talep_aciklama";
            this.talep_aciklama.Size = new System.Drawing.Size(183, 22);
            this.talep_aciklama.TabIndex = 13;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(171, 196);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(125, 22);
            this.label4.TabIndex = 14;
            this.label4.Text = "Talep Tarihi:";
            // 
            // talep_tarihi
            // 
            this.talep_tarihi.Location = new System.Drawing.Point(326, 195);
            this.talep_tarihi.Mask = "00/00/0000";
            this.talep_tarihi.Name = "talep_tarihi";
            this.talep_tarihi.Size = new System.Drawing.Size(183, 22);
            this.talep_tarihi.TabIndex = 15;
            this.talep_tarihi.ValidatingType = typeof(System.DateTime);
            // 
            // Kullanicilarcs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1328, 738);
            this.Controls.Add(this.talep_tarihi);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.talep_aciklama);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.kateogori_id);
            this.Controls.Add(this.kullanici_id);
            this.Controls.Add(this.txtAra);
            this.Controls.Add(this.btn_ara);
            this.Controls.Add(this.btn_sil);
            this.Controls.Add(this.btn_guncelle);
            this.Controls.Add(this.btn_ekle);
            this.Controls.Add(this.btn_listele);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Kullanicilarcs";
            this.Text = "Kullanicilarcs";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Kullanicilarcs_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.talepBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sIRKETDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sIRKETDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingSource sIRKETDataSetBindingSource;
        private SIRKETDataSet sIRKETDataSet;
        private System.Windows.Forms.Button btn_listele;
        private System.Windows.Forms.Button btn_ekle;
        private System.Windows.Forms.Button btn_guncelle;
        private System.Windows.Forms.Button btn_sil;
        private System.Windows.Forms.Button btn_ara;
        private System.Windows.Forms.TextBox txtAra;
        private System.Windows.Forms.TextBox kullanici_id;
        private System.Windows.Forms.TextBox kateogori_id;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.BindingSource talepBindingSource;
        private SIRKETDataSetTableAdapters.TalepTableAdapter talepTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn talepIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn kullaniciIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn kategoriIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn talepAciklamaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn talepTarihiDataGridViewTextBoxColumn;
        private System.Windows.Forms.TextBox talep_aciklama;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.MaskedTextBox talep_tarihi;
    }
}