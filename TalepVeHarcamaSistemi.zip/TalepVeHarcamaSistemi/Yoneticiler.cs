﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace TalepVeHarcamaSistemi
{
    public partial class Yoneticiler : Form
    {
        public Yoneticiler()
        {
            InitializeComponent();
        }

        private void Yoneticiler_Load(object sender, EventArgs e)
        {


        }
        SqlConnection conn = new SqlConnection("Data Source = LAPTOP - P9GCCN15; Initial Catalog = SIRKET; Integrated Security = True; Encrypt = False; Trust Server Certificate = True");

        private void taleplerBtn_Click(object sender, EventArgs e)
        {
            
        }

    }
}

